package edu.kbtu.university.research;

import java.io.*;
import java.time.*;
import java.util.*;

import edu.kbtu.university.users.Researcher;

/**
 * 
 */
public class ResearchPaperBuilder {

    /**
     * Default constructor
     */
    public ResearchPaperBuilder() {
        this.paper = new ResearchPaper();
    }

    /**
     * 
     */
    private ResearchPaper paper;

    /**
     * @param t 
     * @return
     */
    public ResearchPaperBuilder title(String t) {
        paper.setTitle(t);
        return this;
    }

    /**
     * @param a 
     * @return
     */
    public ResearchPaperBuilder authors(List<Researcher> a) {
        paper.setAuthors(a);
        return this;
    }

    /**
     * @param j 
     * @return
     */
    public ResearchPaperBuilder journal(String j) {
        paper.setJournal(j);
        return this;
    }

    /**
     * @param d 
     * @return
     */
    public ResearchPaperBuilder doi(String d) {
        paper.setDoi(d);
        return this;
    }

    /**
     * @param d 
     * @return
     */
    public ResearchPaperBuilder datePublished(LocalDate d) {
        paper.setDatePublished(d);
        return this;
    }

    /**
     * @param n 
     * @return
     */
    public ResearchPaperBuilder citations(int n) {
        paper.setCitations(n);
        return this;
    }

    /**
     * @param n 
     * @return
     */
    public ResearchPaperBuilder pages(int n) {
        paper.setPages(n);
        return this;
    }

    /**
     * @return
     */
    public ResearchPaper build() {
        ResearchPaper built = paper;
        paper = new ResearchPaper();
        return built;
    }

}
